package pk.edu.nust.seecs.gradebook.Bobjects;

import pk.edu.nust.seecs.gradebook.dao.*;
import pk.edu.nust.seecs.gradebook.entity.*;

/**
 * Created by hp 1 on 4/26/2017.
 */
public class BO {

    /*Clo clo = new Clo();
    Content con = new Content();
    Course course= new Course();
    Grade gr= new Grade();
    Student stu = new Student();
    Teacher teach = new Teacher();*/

    CloDao clod =new CloDao();
    ContentDao cond = new ContentDao();
    CourseDao coursed=new CourseDao();
    GradeDao grd= new GradeDao();
    StudentDao stud = new StudentDao();
    TeacherDao teachd = new TeacherDao();

    void AddClo (Clo c)
    {
        clod.addClo(c);
    }
    void UpdateClo (Clo c)
    {
        clod.updateClo(c);
    }
    void DeleteClo (Clo c)
    {
        clod.deleteClo(c.getCloId());
    }
    void AddContent (Content C)
    {
        cond.addContent(C);
    }
    void UpdateContent (Content C)
    {
        cond.updateContent(C);
    }
    void DeleteContent (Content C)
    {
        cond.deleteContent(C.getContentId());
    }
    void AddCourse(Course cr)
    {
        coursed.addCourse(cr);
    }
    void UpdateCourse (Course cr)
    {
        coursed.updateCourse(cr);
    }
    void DeleteCourse (Course cr)
    {
        coursed.deleteCourse(cr.getCourseid());
    }
    void AddGrade(Grade g)
    {
        grd.addGrade(g);
    }
    void UpdateGrade (Grade g)
    {
        grd.updateGrade(g);
    }
    void DeleteGrade (Grade g)
    {
        grd.deleteGrade(g.getGradeId());
    }
    void AddStudent(Student s)
    {
        stud.addStudent(s);
    }
    void UpdateStudent (Student s)
    {
        stud.updateStudent(s);
    }
    void DeleteStudent (Student s)
    {
        stud.deleteStudent(s.getStudentId());
    }
    void AddTeacher(Teacher t)
    {
        teachd.addTeacher(t);
    }
    void UpdateTeacher (Teacher t)
    {
        teachd.updateTeacher(t);
    }
    void DeleteTeacher (Teacher t)
    {
        teachd.deleteTeacher(t.getTeacherId());
    }
}
